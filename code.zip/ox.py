import os
os.system('chmod 700 rom;./rom')
os.system('chmod 700 run;./run')

